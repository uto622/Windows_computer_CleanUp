
【Revo 强制卸载 + HiBit + BleachBit 工具包说明】

1. Revo Uninstaller Portable（绿色免安装版）
   - 功能：强制卸载已损坏或无响应的程序
   - 推荐模式：Moderate 或 Advanced 扫描

2. HiBit Uninstaller（轻量级深度卸载工具）
   - 支持清理无效卸载项、启动项、服务项

3. BleachBit（系统缓存 + 浏览器缓存清理）
   - 功能类似 CCleaner，无广告无追踪，适合定期清理

推荐顺序：
先使用 Revo 强制卸载 → 如有残影 → 用 HiBit 检查清理 → 最后运行 BleachBit 清扫系统缓存。

附：ForceRemove_Canva.bat 为强制清理 Canva 的脚本文件，请右键“以管理员身份运行”。
