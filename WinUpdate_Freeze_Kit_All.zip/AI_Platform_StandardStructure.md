# AI Platform 标准目录结构

## 根路径（建议使用 D 盘）
D:\AIPlatform\
│
├── StableDiffusion\
├── ComfyUI\
├── CUDA\
├── TensorFlow\
├── ET\
├── Blender\
├── DeepSeek\ （未来）
└── Olama\     （未来）

## 补充建议
- 所有模型/脚本单独文件夹管理
- 环境变量配置保存为 `env_setup.bat` 或 `.ps1`
- 安装包统一放入 D:\_Warehouse\ 以便重装迁移