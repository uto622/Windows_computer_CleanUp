# 手动更新策略说明

## 必须更新
- Windows 安全更新
- Microsoft Defender 病毒库
- Visual C++ Redistributable（初次安装后即可忽略）

## 不推荐更新
- 显卡、蓝牙、打印机驱动（建议手动官网下载）
- 可选体验包 / 功能升级包
- Edge、OneDrive（可独立管理）

## 推荐频率
- 每月一次检查系统更新
- 每3个月检查 AI 工具依赖版本（如 transformers、diffusers）

## 工具
- 使用 Manual_Update_Check.ps1 查看日志
- 更新完手动清理 SoftwareDistribution