Get-WinEvent -LogName "Microsoft-Windows-WindowsUpdateClient/Operational" |
Where-Object { $_.Id -in 1, 19, 20, 31, 32 } |
Select-Object TimeCreated, Id, Message -First 30