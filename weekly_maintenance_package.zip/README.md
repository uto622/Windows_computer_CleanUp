# Weekly Maintenance Script 說明文件

## 檔案說明

1. **weekly_maintenance.py**：
   - 自動清理垃圾文件（.tmp, .bak, .log）
   - 搬移並備份資料夾（Documents, Projects, Downloads）
   - 建立 symbolic link（從 C → D）
   - 自動提醒視窗（使用 PowerShell）
   - 記錄執行過程與錯誤到 log：`D:\Logs\weekly_maintenance.log`

2. **ScheduledTask_WeeklyMaintenance.xml**：
   - Windows 任務排程設定檔
   - 每週日 22:00 自動執行上述 Python 腳本

3. **README.md / .txt**：
   - 使用說明與部署流程

## 使用步驟

### 1. 將 weekly_maintenance.py 存放到：
    D:\Scripts\weekly_maintenance.py

### 2. 匯入任務排程
打開 PowerShell（以系統管理員身份），執行：
```powershell
schtasks /create /tn "WeeklyMaintenance" /xml "C:\YourPath\ScheduledTask_WeeklyMaintenance.xml" /f
```

或者用「任務排程器」圖形介面 → 匯入任務 → 設定執行 python + 參數指向腳本路徑

### 3. 確保 Python 環境已安裝並在 PATH 中

## 注意事項

- 所有 symbolic link 操作需要系統管理員權限
- 日誌會記錄於：`D:\Logs\weekly_maintenance.log`
- 若手動執行，建議用 PowerShell 開啟並執行 `python weekly_maintenance.py`

生成時間：2025-05-12 22:33:09
